#pragma once

typedef int in_int_t;
typedef int inout_int_t;

#define N 30

int fir (in_int_t n, inout_int_t A[1000], inout_int_t B[1000]);
