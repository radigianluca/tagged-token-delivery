
typedef int inout_int_t;

#define TSTEPS 3
#define N 100

int jacobi_1d_imper(inout_int_t A[N], inout_int_t B[N]);

