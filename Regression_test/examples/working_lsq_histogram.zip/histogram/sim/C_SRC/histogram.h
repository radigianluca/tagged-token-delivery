typedef int in_int_t;
typedef int in_float_t;
typedef int inout_float_t;
typedef int inout_int_t;

#define S 5

int histogram( in_int_t feature[S], in_int_t weight[S], inout_int_t hist[S], in_int_t n );
