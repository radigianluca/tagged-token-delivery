typedef int inout_int_t;
typedef int out_int_t;

#define N 32

int new_covariance(inout_int_t data[N][N], inout_int_t cov[N][N]);