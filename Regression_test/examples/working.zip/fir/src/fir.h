#pragma once

typedef int in_int_t;
typedef int inout_int_t;

#define N 30

int fir (in_int_t c);
