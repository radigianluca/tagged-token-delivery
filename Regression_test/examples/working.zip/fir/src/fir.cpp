#include "fir.h"
//------------------------------------------------------------------------
// FIR
//------------------------------------------------------------------------

//SEPARATOR_FOR_MAIN

#include <stdlib.h>
#include "fir.h"

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

#define N 30

#define AMOUNT_OF_TEST 1

int fir (in_int_t c) {
	
	int sum = 0;
	//int b = A[0];
	
	for(int i = 100; i >= sum; i--)
		sum += 1;

	return sum + c;
	

	/*for(int i = 1; i < 5; i++)
		A[i] += i;
	return A[4] + c;
	*/
	

	/*int i;
	int z;
	for(i = 0; i < 1000; i++) {
		if(i % 2) {
			z = x *i;
			B[i] = z;
		} else {
			z = x + i;
			C[i] = z;
		}
		A[i] = z;
	}

	return i+x; */
	
	
	/*int sum_1 = 0;
	
		for(int i = 0; i < 1000; i++) {
			if(i % 2)
				sum_1 = i;
			else {
				for(int k = 0; k < 500; k++) {
					//if(i > 10)
						sum_1 = k;

					//else
						//sum_1 *= A[k]*20;
				}
			}

			A[i] = sum_1;
		}


	return sum_1 + x; */
	/*int sum = 0;
	for(int i = 0; i < 5; i++)
		sum = i;

	return sum + x;
	*/
	/*int sum_1 =5;
	int sum_2 = 0;
	int sum_3 = 0;

	for(int i = 0; i < 10; i++)
		for(int k = 0; k < 50; k++)
			sum_1 = i*k;

	for(int j = 0; j < 20; j++)
		for(int z = 0; z < 30; z++)
			sum_2+=j*z;

	for(int i = 0; i < 10; i++)
		for(int k = 0; k < 50; k++)
			sum_3 = i+k;
	

	return sum_1 + sum_2 + sum_3 + x;
	*/
	
	/*int i = 0;
	int gg;
	do {
		if(cond > 1) {
			gg = x;
		} else {
			gg = 0;
		}
		A[i] = gg;
		i++;
	} while(i < 10);
	*/
	/*int sum = 0;
	for(int i = 0; i < 10; i++) {
		sum += A[i];
	}
	return sum;*/

	/*int i;
	for(i = 0; i < 10; i++) {
		if(A[i] > 10)
			break;
	}
	return i; 
	*/

	/*//int x = 3;
	int y = 4;
	for(int i = 0; i < 10; i++) {
		if(cond > i) {
			A[i] = x;
		} else {
			A[i] = y;
		}
		//x++;
		y++;
	}*/
	//return x + y;
	/*int sum  = 3;
	int x;
	for(int i = 0; i < 5; i++) {
		x = B[i];
		//for(int j = 0; j < 10; j++) {
			//for(int k = 0; k < 3; k++)
				sum += x*x*x;
		//}
	}
	return sum+a;
	*/

	/*int sum = 0;
	for(int i = 0; i < 2; i++) {
		for(int j = 0; j < 5; j++) {
			if(a < 3)
				sum +=1;
			else{
				if(a > 0)
					sum += 3;
			}
		}
	}
	return sum+a;		
	*/
}

#define AMOUNT_OF_TEST 1

int main(void){

	int B[5];
	int A[1000];
	int C[1000];
	for(int i = 0; i < 1000; i++) {
		A[i] = rand() % 20;
		//B[i] = rand() % 20;
		C[i] = rand() % 20;
	}

	for(int i = 0; i < 5; i++) {
		B[i] = rand() % 20;
	}
					
	fir(3);
	
	//fir(4, 1);

		/*in_int_t A[1][30];
    inout_int_t s[1][30];
    inout_int_t q[1][30];
    in_int_t p[1][30];
    in_int_t r[1][30];
    
    for(int i = 0; i < 1; ++i){
        for(int y = 0; y < 30; ++y){
            s[i][y] = rand()%100;
            q[i][y] = rand()%100;
            p[i][y] = rand()%100;
            r[i][y] = rand()%100;
            //for(int x = 0; x < 30; ++x){
                A[i][y] = rand()%100;
            //}
        }
    }
    int i = 0;
    fir(A[i], s[i], q[i], p[i], r[i]);
	*/

}



