
//------------------------------------------------------------------------
// Histogram
//------------------------------------------------------------------------


#include <stdlib.h>
#include "histogram.h"

#define AMOUNT_OF_TEST 1

int histogram( in_int_t feature[S], in_int_t weight[S], inout_int_t hist[S], in_int_t n ) 
{
  int m;
  for (int i=0; i<n; ++i) {
    m = feature[i];
    int /*float*/ wt = weight[i];
    int /*float*/ x = hist[m];
    hist[m] = x + wt;
  }

  return m;
}


int main(void){
	  in_int_t feature[AMOUNT_OF_TEST][S];
	  in_int_t weight[AMOUNT_OF_TEST][S];
	  inout_int_t hist[AMOUNT_OF_TEST][S];
	  in_int_t n[AMOUNT_OF_TEST];
    
	srand(13);
	for(int i = 0; i < AMOUNT_OF_TEST; ++i){
    n[i] = S;
    for(int j = 0; j < S; ++j){
      feature[i][j] = (j*2)%S; //rand()%1000;
      weight[i][j] = (j+2)%S;//rand()%100;
      hist[i][j] = (j+4)%S;//rand()%100;
    }
	}

	//for(int i = 0; i < AMOUNT_OF_TEST; ++i){
		int i = 0; 
		histogram(feature[i], weight[i], hist[i], n[i]);
	//}
}

