#pragma once

typedef int in_int_t;
typedef int inout_int_t;

typedef float in_float_t;
typedef float inout_float_t;

#define N 30

int getTanh (inout_int_t A[1000], in_int_t addr[1000]);
