#pragma once

typedef int in_int_t;
typedef int inout_int_t;

#define N 30

int fir ( in_int_t feature[N], in_int_t weight[N], inout_int_t hist[N], in_int_t n);
