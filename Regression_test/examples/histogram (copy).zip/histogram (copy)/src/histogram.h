typedef int in_int_t;
typedef int in_float_t;
typedef int inout_float_t;
typedef int inout_int_t;

int histogram( in_int_t feature[1000], in_int_t weight[1000], inout_int_t hist[1000], in_int_t n );
