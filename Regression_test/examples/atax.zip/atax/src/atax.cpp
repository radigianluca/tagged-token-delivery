/**
 * atax.c: This file is part of the PolyBench/C 3.2 test suite.
 *
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Web address: http://polybench.sourceforge.net
 */
#include "atax.h"

#define NTRU_N 32

int atax(out_int_t r[32], in_int_t a[32], in_int_t b[32])
{
  int k,i,p;

  for(k=0; k<NTRU_N; k++)
  {
    r[k] = 0;
    for(i=1; i<NTRU_N-k; i++)
      r[k] += a[k+i] * b[NTRU_N-i];
    for(i=0; i<k+1; i++)
      r[k] += a[k-i] * b[i];

	p = i+k;
  }

	return p;
}

int main() {
	out_int_t r[NTRU_N];
	in_int_t a[NTRU_N];
	in_int_t b[NTRU_N];

	for(int i = 0; i < NTRU_N; i++) {
  	r[i] = 0;
  	a[i] = i % 10;
  	b[i] = (NTRU_N - i) % 10;
  }

	atax(r, a, b);
}
