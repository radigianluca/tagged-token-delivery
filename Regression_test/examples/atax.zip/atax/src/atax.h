#pragma once

#include <stddef.h>
#include <stdint.h>

typedef uint32_t out_int_t; 
typedef uint32_t in_int_t;

int atax(out_int_t r[32], in_int_t a[32], in_int_t b[32]);
